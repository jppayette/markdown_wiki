<?php

if(  isset($_POST["prenom"]) ){
    echo $_POST["prenom"]."<br>";
    echo $_POST["nom"]."<br>";
} else {
    echo "Aucune valeur entrées";
}

if(  isset($_GET['valeur']) ){
    echo $_GET['valeur'];
}



?>