<?php

// comment je parcours un repertoire 
// pourquoi je ferais ça

// /!!\ Ce fichier montre les bases de scandir et compagnie
// utilisez le fichier explo2 (index.php) qui servira de fichier de reference 
// avec la methode DirectoryIterator


// scandir permet de "scan" le "dir"
//var_dump(   scandir('./')   );

if (isset ( $_GET['directory'] )){
    $directory = $_GET['directory'];
} else {
    $directory = './';
}


$tableauDesRepertoires = scandir($directory);
foreach ($tableauDesRepertoires as $value){
    /*
    echo '<a href="cible">lien</a><br>'; // version 1
    echo "<a href=\"cible\">lien</a><br>"; // version 2
    echo "<a href='cible'>lien</a><br>"; // version 3
    */
    // <a href="cible">lien</a>
    //echo "<a href='$value'>$value</a><br>"; // version 1.1
    //echo "<a href='?directory=" . $value . "'>" . $value . "</a><br>";     // version 2.1 (prefered)


    /*
        Pour détecter si un fichier est un fichier, on fait is_file
        sinon, on fait is_dir pour dire si c'est un fichier(repertoire)

    */
    if ( is_dir($value) ) {
        echo "dossier : "; 
        echo "<a href='?directory=" . $directory  . '/' . $value . "'>" . $value . "</a><br>";
    } else {
        echo "fichier : ";
        echo "<a href='" . $value . "'>" . $value . "</a><br>";

    }













}
?>
