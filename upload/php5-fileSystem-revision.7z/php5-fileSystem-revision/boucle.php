<?php

$tableau = ['elem1','elem2','elem3','elem4'];


foreach ($tableau as $value) {
    echo $value;
}