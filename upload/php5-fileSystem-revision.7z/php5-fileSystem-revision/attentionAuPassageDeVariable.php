        <br>
        cette variable sera toujours présente : 
        <?php
        // syntaxe 1 pour afficher une variable dans un document HTML
         echo $guigui;
        ?>
        

        <!-- Syntaxe 2 pour afficher une variable -->
        cette variable sera toujours présente : 
        <?= $guigui2 ?>