<?php

//  je veux recupérer les informations 
// du get pour les affichers 
// ( et autres traitements )


// $_GET[(NOM DU CHAMP/VARIABLE)];

echo $_GET['prenom']."<br>";
echo $_GET['sexe'];

//var_dump(NOM DU CHAMP/VARIABLE) // premet de debugger
var_dump($_GET['prenom']);
echo "<br>";
var_dump($_GET['sexe']);
echo "<br>";
var_dump($_GET['age']);
echo "<br>";

$variableNum = 234654;
var_dump($variableNum);


http://localhost/php5-revision/contact.php?prenom=Guillaume&se  