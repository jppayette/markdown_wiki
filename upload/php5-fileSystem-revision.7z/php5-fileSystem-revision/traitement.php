<?php

echo " salut, je suis traitement ";


// http://localhost/php5-revision/traitement.php?prenom=qsdfqsdfqsdf&nom=qsdfqsdf

if(  isset($_POST["prenom"]) ){
    echo $_POST["prenom"]."<br>";
    echo $_POST["nom"]."<br>";
} else {
    echo "Aucune valeur entrées";
}

if(  isset($_GET['valeur']) ){
    echo $_GET['valeur'];
}

