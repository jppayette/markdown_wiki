<?php

if(  isset($_POST["nom"]) ){
    echo $_POST["nom"]."<br>";
} else {
    echo "Aucune valeur entrées";
}
?>